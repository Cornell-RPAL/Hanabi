from .core import TomlError
from .parser import load, loads
from .test import translate_to_test
from .writer import dump, dumps